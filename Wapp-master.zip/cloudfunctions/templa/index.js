// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
 var name=event.name2;
 var time=event.time2;
 
  try {
    const result = await cloud.openapi.subscribeMessage.send({
      
      touser: event.openid ,
      page: 'pages/me/me',
      lang: 'zh_CN',
      data: {
        phrase1: {
          value:name
        },
        date5: {
          value:time
        }
      },
      templateId: 'y3-mxycv39Q7I-EfOyUd6KPmgCZfM5I0_80fTB4flPE',
      miniprogramState: 'developer'
    })
    console.log(result)
    
    return result
  } catch (err) {
    console.log(err)
    return err
  }
}