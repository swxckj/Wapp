const db = wx.cloud.database();
const app = getApp();
var openid="";
Page({
  data: {
    score: null,
    teacherInfo: [],
  },
  choosetech: function(res) {
    console.log('000000');
    console.log(res);
    console.log(res.currentTarget.dataset.name);
    console.log(111111111);
    app.globalData.teacher = res.currentTarget.dataset.name;
    wx.navigateTo({
      url: '../teacher/teacher',
    })
  },

  onLoad: function(options) {
    db.collection('teachers').get({
      success:e=>{
        console.log(e.data)
      }
    })
    



    db.collection('teachers').get({
      success: res => {
        console.log(999999)
        console.log(res.data)
        console.log(888888888)
        this.setData({
          teacherInfo: res.data
        })
      } 
    })
    openid=app.globalData.openid;
    console.log(openid);
    db.collection('userInfo').where({_openid:openid}).get({
      success: res => {
        console.log(res);
        this.setData({
          score: res.data[0].score
        })
        if (res.data[0].score < 60)
          wx.showModal({
            title: '错误',
            content: '考试成绩不合格，无法预约，请重新考试！',
            success: res => {
              if (res.confirm) {
                wx.switchTab({
                  url: '../index/index',
                })
              } else if (res.cancel) {
                wx.switchTab({
                  url: '../index/index',
                })
              }
            }
          })
      }
    })
  },
})